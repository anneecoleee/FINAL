package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.HeadlessException;

public class REMOOOVEEE extends JFrame {
	
	Connection conn = null;
	/**
	 * 
	 */
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField txtRE;

	/**
	 * Launch the application.
	 */
//ublic static void main(String[] args) {
//EventQueue.invokeLater(new Runnable() {
//	public void run() {
//		try {
//			REMOOOVEEE frame = new REMOOOVEEE();
//			frame.setVisible(true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//         }
//});
                 // }

	/**
	 * Create the frame.
	 */
	public REMOOOVEEE() {
		setBounds(100, 100, 423, 285);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterProductId = new JLabel("ENTER PRODUCT ID TO REMOVE");
		lblEnterProductId.setFont(new Font("SimSun", Font.BOLD, 17));
		lblEnterProductId.setBounds(60, 69, 278, 37);
		contentPane.add(lblEnterProductId);
		
		txtRE = new JTextField();
		txtRE.setBounds(110, 117, 164, 20);
		contentPane.add(txtRE);
		txtRE.setColumns(10);
		
		JButton btnRemove = new JButton("REMOVE");
		btnRemove.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
									String sql = "Delete from products where Product_ID =?";
								conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
									stat = conn.prepareStatement(sql);
									stat.setString(1,txtRE.getText());
									stat.executeUpdate();
									
								
								JOptionPane.showMessageDialog(null, "Product Deleted");
									
								
								
								}
								catch(SQLException	| HeadlessException ex) {
								
									JOptionPane.showMessageDialog(null, ex);
							
								}
				
				Opening frame = new Opening();	
				frame.ProdTables();
						
				
			}
		});
		btnRemove.setBounds(143, 148, 101, 23);
		contentPane.add(btnRemove);
	}

}
