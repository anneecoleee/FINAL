package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class EmNameUp extends JFrame {
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField txtEID;
	private JTextField txtEN;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
///					EmNameUp frame = new EmNameUp();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public EmNameUp() {
		
		setBounds(100, 100, 302, 292);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterEmployeeId = new JLabel("Enter Employee ID\r\n\r\n");
		lblEnterEmployeeId.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEnterEmployeeId.setBounds(63, 46, 134, 17);
		contentPane.add(lblEnterEmployeeId);
		
		txtEID = new JTextField();
		txtEID.setColumns(10);
		txtEID.setBounds(63, 74, 147, 20);
		contentPane.add(txtEID);
		
		JLabel lblNewEmployeeName = new JLabel("New Employee Name");
		lblNewEmployeeName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewEmployeeName.setBounds(63, 134, 197, 17);
		contentPane.add(lblNewEmployeeName);
		
		txtEN = new JTextField();
		txtEN.setColumns(10);
		txtEN.setBounds(63, 162, 147, 20);
		contentPane.add(txtEN);
		
		JButton button = new JButton("UPDATE\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					String sql = "Update employee SET Employee_Name=? WHERE Employee_ID=?";
						
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtEID.getText());
					stat.setString(1,txtEN.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
				
					
				}
			dispose();
				
			}
		});
		button.setBounds(95, 193, 89, 23);
		contentPane.add(button);
	}

}
