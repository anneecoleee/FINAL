package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class SupPnumber extends JFrame {

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JPanel contentPane;
	private JTextField txtSID;
	private JTextField txtPN;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					SupPnumber frame = new SupPnumber();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public SupPnumber() {
		
		setBounds(100, 100, 267, 293);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Enter Supplier ID\r\n\r\n");
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(49, 58, 134, 17);
		contentPane.add(label);
		
		txtSID = new JTextField();
		txtSID.setColumns(10);
		txtSID.setBounds(49, 79, 147, 20);
		contentPane.add(txtSID);
		
		JLabel lblNewSupplierPhone = new JLabel("New Supplier Phone Number");
		lblNewSupplierPhone.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewSupplierPhone.setBounds(49, 128, 197, 17);
		contentPane.add(lblNewSupplierPhone);
		
		txtPN = new JTextField();
		txtPN.setColumns(10);
		txtPN.setBounds(49, 148, 147, 20);
		contentPane.add(txtPN);
		
		JButton button = new JButton("UPDATE\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					String sql = "Update supplier SET Supplier_Phone_Number=? WHERE Supplier_ID=?";
						
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtSID.getText());
					stat.setString(1,txtPN.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
			dispose();
				
			}
		});
		button.setBounds(75, 179, 89, 23);
		contentPane.add(button);
	}

}
