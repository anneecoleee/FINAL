package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class AddSupplier extends JFrame {

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	private JPanel contentPane;
	private JTextField SupID;
	private final JTextField SupName = new JTextField();
	private JTextField SupEm;
	private JTextField SupAd;
	private JTextField PN;
	private JTextField BN;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					AddSupplier frame = new AddSupplier();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public AddSupplier() {
		setBounds(100, 100, 345, 350);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(205, 133, 63));
		panel.setBounds(0, 0, 329, 46);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ADD A SUPPLIER");
		lblNewLabel.setBounds(86, 11, 176, 30);
		panel.add(lblNewLabel);
		lblNewLabel.setBackground(Color.MAGENTA);
		lblNewLabel.setFont(new Font("Yu Gothic Medium", Font.BOLD, 18));
		
		JLabel lblNewLabel_1 = new JLabel("Supplier Name");
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_1.setBounds(45, 111, 130, 20);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblSupplieremail = new JLabel("Supplier Email");
		lblSupplieremail.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblSupplieremail.setBounds(45, 142, 130, 20);
		contentPane.add(lblSupplieremail);
		
		JLabel lblNewLabel_2 = new JLabel("Supplier Address");
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_2.setBounds(45, 173, 130, 19);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number");
		lblPhoneNumber.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblPhoneNumber.setBounds(45, 203, 130, 14);
		contentPane.add(lblPhoneNumber);
		
		JLabel lblBatchNumber = new JLabel("Batch Number");
		lblBatchNumber.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblBatchNumber.setBounds(45, 234, 143, 14);
		contentPane.add(lblBatchNumber);
		
		SupID = new JTextField();
		SupID.setBounds(179, 78, 113, 20);
		contentPane.add(SupID);
		SupID.setColumns(10);
		SupName.setBounds(179, 105, 113, 20);
		contentPane.add(SupName);
		SupName.setColumns(10);
		
		SupEm = new JTextField();
		SupEm.setBounds(179, 136, 113, 20);
		contentPane.add(SupEm);
		SupEm.setColumns(10);
		
		SupAd = new JTextField();
		SupAd.setColumns(10);
		SupAd.setBounds(179, 167, 113, 20);
		contentPane.add(SupAd);
		
		PN = new JTextField();
		PN.setColumns(10);
		PN.setBounds(179, 197, 113, 20);
		contentPane.add(PN);
		
		BN = new JTextField();
		BN.setColumns(10);
		BN.setBounds(179, 228, 113, 20);
		contentPane.add(BN);
		
		JButton btnNewButton = new JButton("Add Supplier");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					
					String sql = "Insert into supplier" + "(Supplier_ID,Supplier_Name,Supplier_Email,Supplier_Phone_Number,Supplier_Address)" 
									+ "values (?,?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
					stat.setString(1,SupID.getText());
					stat.setString(2,SupName.getText()); 
					stat.setString(3,SupEm.getText());
					stat.setString(4,PN.getText());
					stat.setString(5,SupAd.getText());
					
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Supplier Added");	
					dispose();
					
					
					
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
							
				}
				Opening Frame1 = new Opening();
				Frame1.ProdTables();
			}
		});
		btnNewButton.setBounds(97, 277, 120, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblSupplierid = new JLabel("Supplier ID");
		lblSupplierid.setBounds(45, 70, 109, 30);
		contentPane.add(lblSupplierid);
		lblSupplierid.setFont(new Font("Segoe UI", Font.BOLD, 15));
	}
}
