package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.cj.protocol.Resultset;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class SupEmail extends JFrame {

	Connection conn = null;
	PreparedStatement stat = null;
	Resultset rs = null;
	private JPanel contentPane;
	private JTextField txtSID;
	private JTextField txtEm;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
	///		public void run() {
	//			try {
	//				SupEmail frame = new SupEmail();
	//				frame.setVisible(true);
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//		}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public SupEmail() {
		
		setBounds(100, 100, 275, 288);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Enter Supplier ID\r\n\r\n");
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(45, 47, 134, 17);
		contentPane.add(label);
		
		txtSID = new JTextField();
		txtSID.setColumns(10);
		txtSID.setBounds(45, 69, 147, 20);
		contentPane.add(txtSID);
		
		JLabel lblNewSupplierEmail = new JLabel("New Supplier Email\r\n\r\n");
		lblNewSupplierEmail.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewSupplierEmail.setBounds(45, 114, 197, 17);
		contentPane.add(lblNewSupplierEmail);
		
		txtEm = new JTextField();
		txtEm.setColumns(10);
		txtEm.setBounds(45, 137, 147, 20);
		contentPane.add(txtEm);
		
		JButton button = new JButton("UPDATE\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Update supplier SET Supplier_Email=? WHERE Supplier_ID=?";
						
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtSID.getText());
					stat.setString(1,txtEm.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
			dispose();
				
			}
		});
		button.setBounds(75, 174, 89, 23);
		contentPane.add(button);
	}

}
