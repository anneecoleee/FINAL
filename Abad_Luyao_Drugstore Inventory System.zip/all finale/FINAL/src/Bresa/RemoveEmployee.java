package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class RemoveEmployee extends JFrame {
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	

	private JPanel contentPane;
	private JTextField REID;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					RemoveEmployee frame = new RemoveEmployee();
//					frame.setVisible(true);
//				} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//		}
	//	});
//	}

	/**
	 * Create the frame.
	 */
	public RemoveEmployee() {
		setBounds(100, 100, 504, 283);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterEmployeeId = new JLabel("ENTER EMPLOYEE ID TO REMOVE");
		lblEnterEmployeeId.setFont(new Font("SimSun", Font.BOLD, 17));
		lblEnterEmployeeId.setBounds(100, 63, 278, 37);
		contentPane.add(lblEnterEmployeeId);
		
		REID = new JTextField();
		REID.setColumns(10);
		REID.setBounds(150, 111, 164, 20);
		contentPane.add(REID);
		
		JButton button = new JButton("REMOVE");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					String sql = "Delete from employee where Employee_ID =?";
				conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
					stat.setString(1,REID.getText());
					stat.executeUpdate();
					
				
				JOptionPane.showMessageDialog(null, "EMPLOYEE Deleted");
					
				
				
				}
				catch(SQLException	| HeadlessException ex) {
				
					JOptionPane.showMessageDialog(null, ex);
			
				}

				EmpSTocks frame = new EmpSTocks();
				frame.EmployeeTable();
				dispose();
		
				
			}
		});
		button.setBounds(182, 142, 101, 23);
		contentPane.add(button);
	}

}
